<?php
/**
 * backend/get_approval_rules.php
 * Fetches all global routing configurations.
 */
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

require_once __DIR__ . '/config/db.php';

try {
    $conn = get_db_connection();
    
    $res = $conn->query("SELECT scale_name, role FROM approval_rules ORDER BY scale_name, level ASC");
    $rulesMap = [];
    
    while ($row = $res->fetch_assoc()) {
        $scale = $row['scale_name'];
        if (!isset($rulesMap[$scale])) {
            $rulesMap[$scale] = [];
        }
        $rulesMap[$scale][] = $row['role'];
    }
    
    $rules = [];
    $id = 1;
    foreach ($rulesMap as $scale => $chain) {
        $rules[] = [
            'id' => $id++,
            'scale_name' => $scale,
            'required_chain' => $chain
        ];
    }
    
    $conn->close();
    
    echo json_encode([
        'success' => true,
        'data' => $rules
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
