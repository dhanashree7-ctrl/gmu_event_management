<?php
/**
 * database/db.php
 * ---------------------------------------------------------------
 * Centralised MySQLi connection helper.
 *
 * USAGE:
 *   require_once __DIR__ . '/../config/db.php';
 *   $conn = get_db_connection();
 *
 * Put real credentials in a .env file or server environment
 * variables; never commit them to version control.
 * ---------------------------------------------------------------
 */

// --------------- Configuration --------------------------------
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_PORT', (int) (getenv('DB_PORT') ?: 3306));
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: 'dhanashreessql2025');          // replace in production
define('DB_NAME', getenv('DB_NAME') ?: 'GMU_Events01');
define('DB_CHARSET', 'utf8mb4');

// --------------- Connection factory ---------------------------
/**
 * Returns a live MySQLi connection.
 * Throws a RuntimeException on failure (never leaks credentials).
 *
 * @return mysqli
 * @throws RuntimeException
 */
function get_db_connection(): mysqli
{
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);

    if ($conn->connect_errno) {
        // Log full error server-side; send generic message to client.
        error_log('DB connect error [' . $conn->connect_errno . ']: ' . $conn->connect_error);
        throw new RuntimeException('Database connection failed. Please try again later.');
    }

    // Enforce UTF-8 for all queries in this session.
    if (!$conn->set_charset(DB_CHARSET)) {
        error_log('DB charset error: ' . $conn->error);
        throw new RuntimeException('Database configuration error.');
    }

    return $conn;
}